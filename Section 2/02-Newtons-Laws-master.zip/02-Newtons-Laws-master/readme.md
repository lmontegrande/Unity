# Game Physics 101 - Newton's Laws
The code for my Unity 3D game physics course.

In this section our students learn...

+ Newton's 3 laws of motion.
+ How to improve Unity 3D's drag model.
+ How to impliment universal gravitation and orbits.

Watch me write this code as part of my popular Udemy course. This link will give you a decent GitHub discount: https://www.udemy.com/gamephysics/?couponCode=GitHubSpecial

Enjoy

Ben